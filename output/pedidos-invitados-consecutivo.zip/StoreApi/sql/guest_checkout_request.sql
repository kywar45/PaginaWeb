-- Ejecutar una sola vez antes de subir los cambios PHP.
-- Cada compra genera su registro invitado; un reintento reutiliza ese registro.
ALTER TABLE web_clientes_invitados
    ADD COLUMN checkout_request_hash CHAR(64) DEFAULT NULL,
    ADD UNIQUE KEY uk_guest_checkout_request (checkout_request_hash);
